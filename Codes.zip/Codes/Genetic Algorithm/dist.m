function d=dist(p,q)
d=sqrt(((p(1,1)-q(1,1))^2)+((p(1,2)-q(1,2))^2));
end