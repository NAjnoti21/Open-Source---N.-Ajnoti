To run the gentic algorithm code on Matlab 2022a.

If you want to run for a different budget value then you will have to make changes in budget values in both the code:-
1. SuratObjFnc.mlx (Line 10)
2. Sample_main.mlx (Line 28)

If you want to change the weightage only, then you will have to change w1 and w2 values in Line 58 of SuratObjFnc.mlx.